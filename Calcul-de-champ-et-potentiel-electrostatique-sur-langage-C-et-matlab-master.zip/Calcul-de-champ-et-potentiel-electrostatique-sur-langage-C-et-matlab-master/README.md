# Calcul-de-champ-et-potentiel-electrostatique-sur-langage-C-et-matlab

implémentation d'algorithmes sur le langage C pour simuler un champ électrostatique créé par des distributions de charge.

* programmation : langage C

* simulation et visualisation : Matlab


